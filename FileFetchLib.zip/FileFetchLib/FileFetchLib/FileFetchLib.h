//
//  FileFetchLib.h
//  FileFetchLib
//
//  Created by Mindbowser on 1/17/19.
//  Copyright © 2019 123. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FileFetchLib.
FOUNDATION_EXPORT double FileFetchLibVersionNumber;

//! Project version string for FileFetchLib.
FOUNDATION_EXPORT const unsigned char FileFetchLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FileFetchLib/PublicHeader.h>


